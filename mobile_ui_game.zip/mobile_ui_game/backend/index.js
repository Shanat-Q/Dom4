
const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

let players = [
  { id: 1, name: 'Player1', region: 'Goa', wins: 10, losses: 5 },
  { id: 2, name: 'Player2', region: 'UP', wins: 8, losses: 7 },
];

app.get('/profile/:id', (req, res) => {
  const player = players.find(p => p.id === parseInt(req.params.id));
  if (player) {
    res.json(player);
  } else {
    res.status(404).send('Player not found');
  }
});

app.post('/match', (req, res) => {
  const { region } = req.body;
  const matchedPlayers = players.filter(p => p.region === region);
  res.json(matchedPlayers);
});

app.put('/ranking/:id', (req, res) => {
  const player = players.find(p => p.id === parseInt(req.params.id));
  if (player) {
    player.wins = req.body.wins;
    player.losses = req.body.losses;
    res.json(player);
  } else {
    res.status(404).send('Player not found');
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
