
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function GameScreen({ route }) {
  const { difficulty } = route.params;
  const [player1Time, setPlayer1Time] = useState(300);
  const [player2Time, setPlayer2Time] = useState(300);
  
  useEffect(() => {
    const timer = setInterval(() => {
      // Logic to decrement the timer based on the current player
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  
  return (
    <View style={styles.container}>
      <Text>Difficulty: {difficulty}</Text>
      <View style={styles.timerContainer}>
        <Text>Player 1 Time: {player1Time}s</Text>
        <Text>Player 2 Time: {player2Time}s</Text>
      </View>
      <View style={styles.boardContainer}>
        {/* Game Board Layout */}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  timerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  boardContainer: {},
});
