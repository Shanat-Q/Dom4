
import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

export default function DifficultySelection({ navigation }) {
  return (
    <View style={styles.container}>
      <Button title="Easy" onPress={() => navigation.navigate('Game', { difficulty: 'Easy' })} />
      <Button title="Medium" onPress={() => navigation.navigate('Game', { difficulty: 'Medium' })} />
      <Button title="Hard" onPress={() => navigation.navigate('Game', { difficulty: 'Hard' })} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
