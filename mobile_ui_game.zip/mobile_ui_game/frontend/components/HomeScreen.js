
import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button title="Play with AI" onPress={() => navigation.navigate('DifficultySelection')} />
      <Button title="Two Player" onPress={() => navigation.navigate('TwoPlayerGame')} />
      <Button title="Play Online" onPress={() => navigation.navigate('OnlinePlay')} />
      <Button title="Settings" onPress={() => navigation.navigate('Settings')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
